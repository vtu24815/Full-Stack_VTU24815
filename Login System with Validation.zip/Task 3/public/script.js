const form = document.getElementById("loginForm");
const email = document.getElementById("email");
const password = document.getElementById("password");

const emailError = document.getElementById("emailError");
const passwordError = document.getElementById("passwordError");
const message = document.getElementById("message");

form.addEventListener("submit", async function (e) {
    e.preventDefault();

    emailError.textContent = "";
    passwordError.textContent = "";
    message.textContent = "";

    let isValid = true;

    if (email.value.trim() === "") {
        emailError.textContent = "Email is required";
        isValid = false;
    } else if (!validateEmail(email.value.trim())) {
        emailError.textContent = "Enter a valid email address";
        isValid = false;
    }

    if (password.value.trim() === "") {
        passwordError.textContent = "Password is required";
        isValid = false;
    } else if (password.value.trim().length < 6) {
        passwordError.textContent = "Password must be at least 6 characters";
        isValid = false;
    }

    if (!isValid) {
        return;
    }

    try {
        const response = await fetch("/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                email: email.value.trim(),
                password: password.value.trim()
            })
        });

        const data = await response.json();

        if (data.success) {
            message.style.color = "#86efac";
            message.textContent = data.message;
        } else {
            message.style.color = "#fca5a5";
            message.textContent = data.message;
        }
    } catch (error) {
        message.style.color = "#fca5a5";
        message.textContent = "Server connection failed";
    }
});

function validateEmail(email) {
    const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return pattern.test(email);
}