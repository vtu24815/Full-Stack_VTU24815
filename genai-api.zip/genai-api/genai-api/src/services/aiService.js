import axios from "axios";

export const generateAIResponse = async (prompt) => {
  try {
    console.log("KEY:", process.env.OPENAI_API_KEY);

    const response = await axios.post(
      "https://api.openai.com/v1/chat/completions",
      {
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: prompt }]
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
          "Content-Type": "application/json"
        }
      }
    );

    return response.data.choices[0].message.content;

  } catch (error) {
    console.log("OPENAI ERROR FULL:", error.response?.data);
    throw error;
  }
};