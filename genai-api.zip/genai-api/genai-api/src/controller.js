import { generateAIResponse } from "./services/aiService.js";

export const generateText = async (req, res) => {
  try {
    const { prompt } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: "Prompt is required" });
    }

    const result = await generateAIResponse(prompt);

    res.json({ response: result });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};