import express from "express";
import { generateText } from "./controller.js";

const router = express.Router();

router.post("/generate", generateText);

export default router;