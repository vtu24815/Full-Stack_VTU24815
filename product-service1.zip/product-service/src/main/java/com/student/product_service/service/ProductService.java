package com.student.product_service.service;

import com.student.product_service.entity.Product;
import com.student.product_service.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public Product addProduct(Product product) {
        return productRepository.save(product);
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Product getProductById(Long id) {
        return productRepository.findById(id).orElse(null);
    }

    public Product updateProduct(Long id, Product newProduct) {
        Product product = productRepository.findById(id).orElse(null);

        if (product != null) {
            product.setName(newProduct.getName());
            product.setCategory(newProduct.getCategory());
            product.setPrice(newProduct.getPrice());
            product.setQuantity(newProduct.getQuantity());
            return productRepository.save(product);
        }
        return null;
    }

    public String deleteProduct(Long id) {
        if (productRepository.existsById(id)) {
            productRepository.deleteById(id);
            return "Product deleted successfully";
        }
        return "Product not found";
    }
}