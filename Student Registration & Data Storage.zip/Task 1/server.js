const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static("public"));

// MySQL connection
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "tehazeeb@2005",
    database: "student_db"
});

// Insert data
app.post("/addStudent", (req, res) => {
    const { name, email, dob, department, phone } = req.body;

    const sql = "INSERT INTO students (name, email, dob, department, phone) VALUES (?, ?, ?, ?, ?)";

    db.query(sql, [name, email, dob, department, phone], (err, result) => {
        if (err) return res.send(err);
        res.send("Student Added");
    });
});

// Retrieve data (SELECT)
app.get("/getStudents", (req, res) => {
    db.query("SELECT * FROM students", (err, result) => {
        if (err) return res.send(err);
        res.json(result);
    });
});

app.listen(5000, () => {
    console.log("Server running on port 5000");
});