package com.student.order_service.service;

import com.student.order_service.dto.Product;
import com.student.order_service.entity.Order;
import com.student.order_service.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private RestTemplate restTemplate;

    public Order placeOrder(Order order) {
    	Product product = restTemplate.getForObject(
    	        "http://PRODUCT-SERVICE/products/" + order.getProductId(),
    	        Product.class
    	);

        if (product != null) {
            return orderRepository.save(order);
        }
        return null;
    }

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Order getOrderById(Long id) {
        return orderRepository.findById(id).orElse(null);
    }
}
