package com.student.student_jpa.repository;

import com.student.student_jpa.entity.Student;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface StudentRepository extends JpaRepository<Student, Long> {
    List<Student> findByDepartment(String department);
    List<Student> findByAgeGreaterThan(int age);
    List<Student> findByDepartmentAndAgeGreaterThan(String department, int age);
    Page<Student> findByDepartment(String department, Pageable pageable);
}