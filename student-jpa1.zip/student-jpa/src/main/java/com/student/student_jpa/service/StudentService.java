package com.student.student_jpa.service;

import com.student.student_jpa.entity.Student;
import com.student.student_jpa.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;
    public Student saveStudent(Student student) {
        return studentRepository.save(student);
    }
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }
    public List<Student> getByDepartment(String department) {
        return studentRepository.findByDepartment(department);
    }
    public List<Student> getByAge(int age) {
        return studentRepository.findByAgeGreaterThan(age);
    }
    public List<Student> getByDeptAndAge(String dept, int age) {
        return studentRepository.findByDepartmentAndAgeGreaterThan(dept, age);
    }
    public List<Student> sortByName() {
        return studentRepository.findAll(Sort.by(Sort.Direction.ASC, "name"));
    }
    public List<Student> sortByAge() {
        return studentRepository.findAll(Sort.by(Sort.Direction.ASC, "age"));
    }
    public Page<Student> getWithPagination(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return studentRepository.findAll(pageable);
    }
    public Page<Student> getByDeptWithPagination(String dept, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("name"));
        return studentRepository.findByDepartment(dept, pageable);
    }
}