package com.student.student_jpa.controller;

import com.student.student_jpa.entity.Student;
import com.student.student_jpa.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentService studentService;
    @PostMapping
    public Student saveStudent(@RequestBody Student student) {
        return studentService.saveStudent(student);
    }
    @GetMapping
    public List<Student> getAllStudents() {
        return studentService.getAllStudents();
    }
    @GetMapping("/department/{dept}")
    public List<Student> getByDepartment(@PathVariable String dept) {
        return studentService.getByDepartment(dept);
    }
    @GetMapping("/age/{age}")
    public List<Student> getByAge(@PathVariable int age) {
        return studentService.getByAge(age);
    }
    @GetMapping("/filter/{dept}/{age}")
    public List<Student> getByDeptAndAge(@PathVariable String dept, @PathVariable int age) {
        return studentService.getByDeptAndAge(dept, age);
    }
    @GetMapping("/sort/name")
    public List<Student> sortByName() {
        return studentService.sortByName();
    }
    @GetMapping("/sort/age")
    public List<Student> sortByAge() {
        return studentService.sortByAge();
    }
    @GetMapping("/page")
    public Page<Student> getWithPagination(@RequestParam int page, @RequestParam int size) {
        return studentService.getWithPagination(page, size);
    }
    @GetMapping("/page/department/{dept}")
    public Page<Student> getByDeptWithPagination(
            @PathVariable String dept,
            @RequestParam int page,
            @RequestParam int size) {
        return studentService.getByDeptWithPagination(dept, page, size);
    }
}