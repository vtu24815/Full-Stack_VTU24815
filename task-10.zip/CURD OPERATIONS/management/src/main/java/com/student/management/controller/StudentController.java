package com.student.management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.student.management.entity.Student1;
import com.student.management.service.StudentService;

@RestController
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentService service;

    @PostMapping
    public Student1 create(@RequestBody Student1 s) {
        return service.save(s);
    }

    @GetMapping
    public List<Student1> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public Student1 getById(@PathVariable Long id) {
        return service.getById(id);
    }

    @PutMapping("/{id}")
    public Student1 update(@PathVariable Long id, @RequestBody Student1 s) {
        s.setId(id);
        return service.save(s);
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id) {
        service.delete(id);
        return "Deleted successfully";
    }
}