package com.student.management.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import com.student.management.entity.Student1;
import com.student.management.repository.StudentRepository;

@Service
public class StudentService {

    @Autowired
    private StudentRepository repo;

    public Student1 save(Student1 s) {
        return repo.save(s);
    }

    public List<Student1> getAll() {
        return repo.findAll();
    }

    public Student1 getById(Long id) {
        return repo.findById(id).orElse(null);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }
}