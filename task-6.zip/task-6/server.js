const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// DB CONNECTION
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "MySQL@1234",
    database: "audit_demo1"
});

db.connect(err => {
    if (err) {
        console.log("DB Connection Error:", err);
    } else {
        console.log("MySQL Connected");
    }
});


// ===================== INSERT TRANSACTION =====================
app.post("/transaction", (req, res) => {
    const { user_name, amount, action_type } = req.body;

    console.log("INSERT BODY:", req.body);

    if (!user_name || !amount) {
        return res.status(400).send("Missing required fields");
    }

    const sql = "INSERT INTO transactions (user_name, amount, action_type) VALUES (?, ?, ?)";

    db.query(sql, [user_name, amount, action_type], (err, result) => {
        if (err) {
            console.log(err);
            return res.send(err);
        }

        res.send({
            message: "Inserted successfully",
            id: result.insertId
        });
    });
});


// ===================== UPDATE TRANSACTION =====================
app.put("/transaction/:id", (req, res) => {
    const { amount } = req.body;

    console.log("UPDATE ID:", req.params.id, "BODY:", req.body);

    if (!amount) {
        return res.status(400).send("Amount is required");
    }

    const sql = "UPDATE transactions SET amount=? WHERE id=?";

    db.query(sql, [amount, req.params.id], (err, result) => {
        if (err) {
            console.log(err);
            return res.send(err);
        }

        res.send({
            message: "Updated successfully",
            id: req.params.id
        });
    });
});


// ===================== GET LOGS =====================
app.get("/logs", (req, res) => {
    db.query("SELECT * FROM audit_log ORDER BY log_time DESC", (err, result) => {
        if (err) return res.send(err);
        res.json(result);
    });
});


// ===================== DAILY REPORT =====================
app.get("/report", (req, res) => {
    db.query("SELECT * FROM daily_activity", (err, result) => {
        if (err) return res.send(err);
        res.json(result);
    });
});


// ===================== START SERVER =====================
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});