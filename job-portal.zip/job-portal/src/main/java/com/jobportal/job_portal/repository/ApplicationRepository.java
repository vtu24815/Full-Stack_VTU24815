package com.jobportal.job_portal.repository;

import com.jobportal.job_portal.entity.Application;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApplicationRepository extends JpaRepository<Application, Long> {
}