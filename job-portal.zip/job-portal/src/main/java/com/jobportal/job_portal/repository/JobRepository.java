package com.jobportal.job_portal.repository;
import com.jobportal.job_portal.entity.Job;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface JobRepository extends JpaRepository<Job, Long> {

    List<Job> findByCategory(String category);

    List<Job> findByLocation(String location);

    List<Job> findByTitleContainingIgnoreCase(String keyword);
}
