package com.jobportal.job_portal.controller;

import com.jobportal.job_portal.entity.Application;
import com.jobportal.job_portal.entity.Job;
import com.jobportal.job_portal.service.ApplicationService;
import com.jobportal.job_portal.service.JobService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class ApplicationController {

    @Autowired
    private ApplicationService applicationService;

    @Autowired
    private JobService jobService;

    // 👉 Show Apply Form
    @GetMapping("/apply/{jobId}")
    public String showApplyForm(@PathVariable Long jobId, Model model) {
        model.addAttribute("jobId", jobId);
        return "apply-job";
    }

    // 👉 Submit Application (FINAL VERSION)
    @PostMapping("/submit-application")
    public String submitApplication(
            @RequestParam String applicantName,
            @RequestParam String email,
            @RequestParam String resume,
            @RequestParam Long jobId) {

        Application application = new Application();

        application.setApplicantName(applicantName);
        application.setEmail(email);
        application.setResume(resume);

        // 🔥 OPTIONAL IMPROVEMENT (IMPORTANT FOR DEMO)
        application.setStatus("APPLIED");

        // Fetch job using ID
        Job job = jobService.getJobById(jobId);
        application.setJob(job);

        applicationService.applyJob(application);

        return "redirect:/applications";
    }

    // 👉 View Applications
    @GetMapping("/applications")
    public String viewApplications(Model model) {
        model.addAttribute("applications", applicationService.getAllApplications());
        return "applications";
    }
}