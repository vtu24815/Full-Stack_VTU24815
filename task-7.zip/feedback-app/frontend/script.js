// reusable validation functions
function validateName() {
    let name = document.getElementById("name").value;
    if (name.length < 3) {
        showStatus("Name must be at least 3 characters", "red");
    } else {
        showStatus("", "");
    }
}

function validateEmail() {
    let email = document.getElementById("email").value;
    let regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!regex.test(email)) {
        showStatus("Invalid email format", "red");
    } else {
        showStatus("", "");
    }
}

function validateMessage() {
    let msg = document.getElementById("message").value;
    if (msg.length < 10) {
        showStatus("Message too short", "red");
    } else {
        showStatus("", "");
    }
}

// hover highlight function
function highlight(el) {
    el.style.boxShadow = "0 0 10px blue";
}

// status display helper
function showStatus(msg, color) {
    let status = document.getElementById("status");
    status.innerText = msg;
    status.style.color = color;
}

// submit on double click
async function submitForm() {
    let data = {
        name: document.getElementById("name").value,
        email: document.getElementById("email").value,
        message: document.getElementById("message").value
    };

    const res = await fetch("http://localhost:3000/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    });

    const result = await res.json();

    if (result.success) {
        showStatus("Feedback submitted successfully!", "green");
    } else {
        showStatus("Submission failed", "red");
    }
}