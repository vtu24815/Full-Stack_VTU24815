const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "tehazeeb@2005",
    database: "student_db"
});

// Add student
app.post("/addStudent", (req, res) => {
    const { name, email, dob, department, phone } = req.body;

    const sql = "INSERT INTO students (name,email,dob,department,phone) VALUES (?,?,?,?,?)";

    db.query(sql, [name, email, dob, department, phone], (err) => {
        if (err) return res.send(err);
        res.send("Added");
    });
});

// Get students (search + filter + sort + pagination)
app.get("/students", (req, res) => {
    let { search, sortBy, department, page = 1, limit = 5 } = req.query;

    page = parseInt(page);
    limit = parseInt(limit);
    const offset = (page - 1) * limit;

    let sql = "SELECT * FROM students WHERE 1=1";
    let values = [];

    if (search) {
        sql += " AND name LIKE ?";
        values.push(`%${search}%`);
    }

    if (department) {
        sql += " AND department = ?";
        values.push(department);
    }

    if (sortBy === "name") sql += " ORDER BY name ASC";
    if (sortBy === "dob") sql += " ORDER BY dob ASC";

    sql += " LIMIT ? OFFSET ?";
    values.push(limit, offset);

    db.query(sql, values, (err, result) => {
        if (err) return res.send(err);
        res.json(result);
    });
});

// Department count
app.get("/departmentCount", (req, res) => {
    db.query(
        "SELECT department, COUNT(*) as count FROM students GROUP BY department",
        (err, result) => {
            if (err) return res.send(err);
            res.json(result);
        }
    );
});

app.listen(5000, () => console.log("Server running on port 5000"));