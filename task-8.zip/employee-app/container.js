const EmployeeService = require("./services/employeeService");
console.log("EmployeeService:", EmployeeService);
class Container {
    constructor() {
        this.beans = {};
    }

    getBean(name) {
        if (!this.beans[name]) {
            if (name === "employeeService") {
                this.beans[name] = new EmployeeService();
            }
        }
        return this.beans[name];
    }
}

module.exports = new Container();
