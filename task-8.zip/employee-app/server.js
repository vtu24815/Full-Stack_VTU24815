const express = require("express");
const path = require("path");
const Employee = require("./models/employee");
const container = require("./container");

const app = express();
app.use(express.json());
app.use(express.static("public"));

// DI: Injecting dependency from container
const employeeService = container.getBean("employeeService");

// Add employee
app.post("/add", (req, res) => {
    console.log("Received data:", req.body); 
    const { id, name, role } = req.body;
    const emp = new Employee(id, name, role);

    employeeService.addEmployee(emp);
    res.send("Employee Added");
});

// Get all employees
app.get("/employees", (req, res) => {
    res.json(employeeService.getAllEmployees());
});

app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});