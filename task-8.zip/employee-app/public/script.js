function addEmployee() {
    const id = document.getElementById("id").value.trim();
    const name = document.getElementById("name").value.trim();
    const role = document.getElementById("role").value.trim();

    // Basic validation
    if (!id || !name || !role) {
        alert("Please fill all fields");
        return;
    }

    fetch("/add", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ id, name, role })
    })
    .then(res => res.text())
    .then(msg => {
        alert(msg);

        // Clear inputs after adding
        document.getElementById("id").value = "";
        document.getElementById("name").value = "";
        document.getElementById("role").value = "";

        loadEmployees(); // Refresh list
    })
    .catch(err => {
        console.error("Error adding employee:", err);
    });
}

function loadEmployees() {
    fetch("/employees")
        .then(res => res.json())
        .then(data => {
            const list = document.getElementById("list");
            list.innerHTML = "";

            // Handle empty list
            if (!data || data.length === 0) {
                list.innerHTML = "<li>No employees found</li>";
                return;
            }

            data.forEach(emp => {
                const li = document.createElement("li");
                li.textContent = `${emp.id} - ${emp.name} - ${emp.role}`;
                list.appendChild(li);
            });
        })
        .catch(err => {
            console.error("Error loading employees:", err);
        });
}

// Load employees when page loads
window.onload = loadEmployees;