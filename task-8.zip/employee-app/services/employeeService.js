class EmployeeService {
    constructor() {
        this.employees = [];
    }

    addEmployee(emp) {
        this.employees.push(emp);
    }

    getAllEmployees() {
        return this.employees;
    }
}

module.exports = EmployeeService;